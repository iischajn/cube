(function() {
    var srcPath = './js/';
    document.write('<script src="' + srcPath + 'nav.js"><\/script>');
}());


$(function() {
	app.ready();
});
