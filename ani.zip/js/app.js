$.namespace('cube.app');

// cube.app = (function(){
//     return function(){

//     }
// })();


cube.app = (function(){
    return function(){

    }
})();


cube.app.route = (function(){
    var that = {};
    var variable = {};

    function execute() {
        var t, a, r;
        return 
        a = variable.enter, 
        r = variable.leave, 
        r !== a || "index" === r || "article" === r ? (
            app.page = a, 
            e.onEnter(), 
            $.history.push(), 
            "function" == typeof(t = app.fn).back && t.back(), 
            e.stat()
        ) : void 0
    }


    app.route = function() {
        var t, a, r, i;
        return 
        r = n.leave = app.page || "index", 
        t = n.enter = $.hash("page"), 
        i = e.list || (
            e.list = function() {
            var e;
            e = [];
            for (a in app.map) e.push(a);
            return e
        }()), 
        c.call(i, t) >= 0 ? 
        $.require({ html: [r, t], style: [r, t] }).done(function() {
            return e.execute()
        }) : ($.i("error", "there has got no page [" + t + "] in the map of router"), 
        void $.history.back())
    }, 
    n = e.variable = {}, 

    return function(){
        , 
        e.stat = function() {
            var e;
            return e = n.enter, "article" === e ? void app.stat("click", $.hash("aid"), null) : app.stat("page", e, null)
        }, 
        e.onEnter = function() {
            var t, a, r;
            return a = n.enter, r = n.pageEnter = $("#" + a), t = n.bar = r.children(".bar"), r.data().ready ? e.enter() : (app.wait(!0), void $.require({ script: a }).done(function() {
                var n;
                return (n = r.data().init) ? void n(function() {
                    return e.init()
                }) : e.init()
            }))
        }, 
        e.init = function() {
            var t, a, r, i;
            return a = n.enter, i = n.pageEnter, t = n.bar, r = i.children(".nav"), app.bindScroll(a), t.length && t.on("click", ".btn", function() {
                var e, n;
                return app.sound(), n = $(this), e = "_active", n.addClass(e).onAnimationEnd(function() {
                    return n.removeClass(e)
                })
            }), r.length && r.on("click", ".btn", function() {
                return app.sound()
            }), i.data().ready = !0, e.enter()
        }, 
        e.enter = function() {
            var t, a;
            return a = n.pageEnter, (t = a.data().enter) ? (app.wait(!0), void t(function() {
                return e.enterAfter()
            })) : e.enterAfter()
        }, e.enterAfter = function() {
            var t, a, r, i, o;
            return i = n.pageEnter, t = n.bar, r = i.children(".content"), i.css($.vendor({ transform: "translate3d(0, 0, 0)", filter: "brightness(1)" })).removeClass("hidden"), app.scroll.top = r.scrollTop() || 0, "function" == typeof(a = $("#nav").data()).check && a.check(), o = $.trim(t.find(".title").text()), o.length && "anitama" !== o.toLowerCase() || (o = app.title), document.title = o, e.onLeave(), app.wait(!1)
        }, e.onLeave = function() {
            var t, a, r;
            return a = n.leave, r = n.pageLeave = $("#" + a), r.data().ready ? (t = r.data().leave) ? void t(function() {
                return e.leave()
            }) : e.leave() : void 0
        }, e.leave = function() {
            var t, a, r;
            return t = n.enter, a = n.leave, r = n.pageLeave, e.screenShot(), r.data().lastActiveTimestamp = $.now(), t !== a ? r.addClass("hidden") : void 0
        }, e.screenShot = function() {
            var t, a, r;
            return t = n.enter, a = n.leave, r = n.pageLeave, "browser" !== app.shell && "index" !== t && "special" !== t && "explore" !== t && "mine" !== t ? c.call(app.map[t], a) >= 0 ? void app.screenshot(function(n) {
                return r.data().screenshot = n, e.screenSet()
            }) : e.screenSet() : void 0
        }, e.screenSet = function() {
            return $.next(500, function() {
                var e, n, t;
                return t = $.history.last()[1], e = $("#" + t), e.length && (n = e.data().screenshot) ? o.css({ "background-image": "url(" + n + ")" }) : void 0
            })
        }


    }
})();




(function() {
    var e, n, t, a, r, i, o, p = [].slice,
        c = [].indexOf || function(e) {
            for (var n = 0, t = this.length; t > n; n++)
                if (n in this && this[n] === e) return n;
            return -1
        };
    ! function() {
        var e, n;
        return e = 


    }(),

    app.back = function() {
            var e, n, t;
            return app.fn.back ? void("function" == typeof(e = app.fn).back && e.back()) : "index" !== app.page ? void $.history.back() : (t = $("#index"), n = t.data(), 0 !== n.tabb.index ? void n.tabb.eq(0) : n.exitCheck ? app.exit() : ($.info("再次点击后退键退出应用"), n.exitCheck = !0, clearTimeout(n.exitTimer), void(n.exitTimer = $.next(3e3, function() {
                return n.exitCheck = !1
            }))))
        },
        app.bindScroll = function(e) {
            var n, t;
            return n = function() {
                var e, n, t;
                return e = app.scroll, n = $(this), t = n.scrollTop(), e._scrollEnd || (e._scrollEnd = function() {
                    return clearTimeout(e.timer), e.timer = $.next(200, function() {
                        return e.scrolling = !1, n.triggerHandler("scrollend")
                    })
                }), e.scrolling ? e._scrollEnd() : (e.scrolling = !0, e.origin = e.top, e.startTime = $.now(), n.triggerHandler("scrollstart"), e._scrollEnd()), e.direction = t > e.top ? "down" : "up", e.distance = t - e.origin, e.top = t, n.triggerHandler("_scroll")
            }, t = _.throttle(n, 100), $("#" + e).find(".content").on("scroll", t)
        },
        app.bindSwipeToggle = function() {
            var e, n, t;
            return t = $("#" + app.page), n = (e = t.data())._swipeToggle || (e._swipeToggle = {}), t.swipe({ direction: "x" }).on("swipestart", function() {
                return n.fired = !0
            }).on("swipemove", function(e) {
                var t, a;
                if (n.fired && !(Math.abs(e.distance) < .25 * app.innerWidth)) return t = $("#nav a.active"), e.distance > 0 ? (a = t.prev(), a.length ? a.is(":visible") || (a = a.prev()) : a = $("#nav a:visible").last()) : (a = t.next(), a.length ? a.is(":visible") || (a = a.next()) : a = $("#nav a:visible").first()), a.click(), n.fired = !1
            }).on("swipeend", function() {
                return n.fired ? n.fired = !1 : void 0
            })
        }, document.ondragover = document.ondrop = function(e) {
            return e.preventDefault(), !1
        }, "electron" === app.shell && o.on("dragstart", "a, img", function(e) {
            return e.preventDefault()
        }),

        app.confirm = function(e, n) {
            var t;
            return t = $.extend({ title: "应用", hint: "确定,取消" }, e), window.confirm(t.message) && "function" == typeof n ? n() : void 0
        },
        app.reboot = function() {
            return location.reload()
        },
        app.wait = function(e) {
            var n, t;
            return n = $("#wait"), t = app.wait, e ? t.waiting || (clearTimeout(t.timer), t.timer = $.next(200, function() {
                return n.removeClass("hidden")
            }), t.waiting = !0) : t.waiting && (clearTimeout(t.timer), n.addClass("hidden"), t.waiting = !1), n
        },
        app.audio = function(e) {
            var n;
            return n = $("#audio"), n.length || (o.append('<audio id="audio"></audio>'), n = $("#audio")), e ? (n[0].src = e, n[0].play()) : n[0].pause()
        },
        app.shake = function(e) {
            var n;
            return n = "shake animated", e.addClass(n).onAnimationEnd(function() {
                return e.removeClass(n)
            })
        }
        //,
        // app.splash = function(){
        //     a = $('#splash'),
        //     n = a.find('.bg'),
        //     e = { title: "动画魂", origin: "动画魂制作委员会",url:"http://cdn.animetamashi.cn/1089b4689f3312d4/img/0e2c20-cover"}, 
        //     e.url && n.css({ "background-image": "url(" + e.url + ")" }), 
        //     a.find(".version").text(e.title + " © " + e.origin), 
        //     a.removeClass("hidden"), 

        //     $.next(function() {
        //     return n.css($.vendor({ transform: "scale(1)" })).animate($.vendor({ transform: "scale(2.2)" }), 1e4, function() {
        //         return t.hide()
        //         })
        //     })
        // }
    app.ready = function() {
        $('#splash').addClass('hidden');
    }
}).call(this);
