
(function() {
    var a, n, i, e;
    i = $(window), e = $("#stage"), n = $("#nav"), a = n.data(), a.show = function() {
        return n.removeClass("hidden")
    }, a.hide = function() {
        return n.addClass("hidden")
    }, a.check = function() {
        var n;
        return "index" === (n = app.page) || "special" === n || "explore" === n || "mine" === n ? (a.show(), $("#btn-" + app.page + "-nav").switchClass("active")) : a.hide()
    }, a["goto"] = _.throttle(function(a) {
        var n, i;
        if (n = "_active", a.addClass(n).onAnimationEnd(function() {
                return a.removeClass(n)
            }), i = a.data().page, "special" === i) {
            if ("application" !== app.shell) return void(location.hash = "#page=article;aid=1982f1b6dbd05feb");
            if (!app.online) return void(location.hash = "#page=login")
        }
        return location.hash = "#page=" + i
    }, 500, { trailing: !1 }), n.on("click", "a", function() {
        return a["goto"]($(this))//app.sound(),
    })
}).call(this);
