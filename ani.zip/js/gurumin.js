//$.os $.browser $.parseString $.parseJson
//$.parseSize $.parseRgb $.parseTime $.parseShortDate
//$.route $.hash $.hash.parse $.history $.info $.log 
(function() {
    var e, t, n, r = [].slice,
        a = [].indexOf || function(e) {
            for (var t = 0, n = this.length; n > t; t++)
                if (t in this && this[t] === e) return t;
            return -1
        };
    $.ajaxSetup({ cache: true }), 
    //$.os $.browser
    (function() {
        var e, t, n, r, a, i, o, s, c, u, l, d, h, f, p, v, m, g, w, b, x, y, k, C, S, _;
        return x = navigator.userAgent, p = navigator.platform, h = $.os = {}, r = $.browser = {}, y = x.match(/Web[kK]it[\/]{0,1}([\d.]+)/), e = x.match(/(Android);?[\s\/]+([\d.]+)?/), f = !!x.match(/\(Macintosh\; Intel /), c = x.match(/(iPad).*OS\s([\d_]+)/), l = x.match(/(iPod)(.*OS\s([\d_]+))?/), u = !c && x.match(/(iPhone\sOS)\s([\d_]+)/), k = x.match(/(webOS|hpwOS)[\s\/]([\d.]+)/), S = /Win\d{2}|Windows/.test(p), _ = x.match(/Windows Phone ([\d.]+)/), b = k && x.match(/TouchPad/), d = x.match(/Kindle\/([\d.]+)/), w = x.match(/Silk\/([\d._]+)/), n = x.match(/(BlackBerry).*Version\/([\d.]+)/), t = x.match(/(BB10).*Version\/([\d.]+)/), m = x.match(/(RIM\sTablet\sOS)\s([\d.]+)/), v = x.match(/PlayBook/), a = x.match(/Chrome\/([\d.]+)/) || x.match(/CriOS\/([\d.]+)/), i = x.match(/Firefox\/([\d.]+)/), o = x.match(/\((?:Mobile|Tablet); rv:([\d.]+)\).*Firefox\/[\d.]+/), s = x.match(/MSIE\s([\d.]+)/) || x.match(/Trident\/[\d](?=[^\?]+).*rv:([0-9.].)/), C = !a && x.match(/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/), g = C || x.match(/Version\/([\d.]+)([^S](Safari)|[^M]*(Mobile)[^S]*(Safari))/), (r.webkit = !!y) && (r.version = y[1]), e && (h.android = true, h.version = e[2]), u && !l && (h.ios = h.iphone = true, h.version = u[2].replace(/_/g, ".")), c && (h.ios = h.ipad = true, h.version = c[2].replace(/_/g, ".")), l && (h.ios = h.ipod = true, h.version = l[3] ? l[3].replace(/_/g, ".") : null), _ && (h.wp = true, h.version = _[1]), k && (h.webos = true, h.version = k[2]), b && (h.touchpad = true), n && (h.blackberry = true, h.version = n[2]), t && (h.bb10 = true, h.version = t[2]), m && (h.rimtabletos = true, h.version = m[2]), v && (r.playbook = true), d && (h.kindle = true, h.version = d[1]), w && (r.silk = true, r.version = w[1]), !w && h.android && x.match(/Kindle Fire/) && (r.silk = true), a && (r.chrome = true, r.version = a[1]), i && (r.firefox = true, r.version = i[1]), o && (h.firefoxos = true, h.version = o[1]), s && (r.ie = true, r.version = s[1]), g && (f || h.ios || S) && (r.safari = true, h.ios || (r.version = g[1])), C && (r.webview = true), h.tablet = !!(c || v || e && !x.match(/Mobile/) || i && x.match(/Tablet/) || s && !x.match(/Phone/) && x.match(/Touch/)), h.phone = !(h.tablet || h.ipod || !(e || u || k || n || t || a && x.match(/Android/) || a && x.match(/CriOS\/([\d.]+)/) || i && x.match(/Mobile/) || s && x.match(/Touch/)))
    }());

    window.cordova || (window.cordova = { notCordova: true, plugins: {} }), 
    
    t = $(window), 
    n = $("#stage"), 
    n.data({ width: t.width(), height: t.height(), scrollTop: 0, startTime: $.now(), status: {}, timer: {}, scroll: {}, tap: {}, fn: {}, log: [] }),

    e = window.app = n.data(),
        function() {
            var t, r;
            return t = [], r = navigator.userAgent, $.os.android ? (t.push("os-android"), e.os = "android") : $.os.ios ? (t.push("os-ios"), e.os = "ios") : (t.push("os-web"), e.os = "web"), $.os.phone ? (t.push("device-phone"), e.device = "phone") : $.os.tablet ? (t.push("device-tablet"), e.device = "tablet") : (t.push("device-desktop"), e.device = "desktop"), ~r.search(/MicroMessenger/i) ? (t.push("shell-wechat"), e.shell = "wechat") : ~r.search(/Electron/i) ? (t.push("shell-electron"), e.shell = "electron") : cordova.notCordova ? (t.push("shell-browser"), e.shell = "browser") : (t.push("shell-application"), e.shell = "application"), n.addClass(t.join(" "))
        }(), 

        $.parseString = function(e) {
            var t, n, r;
            switch ($.type(t = e)) {
                case "string":
                    return t;
                case "number":
                    return t.toString();
                case "array":
                    return JSON.stringify({ _obj: t }).replace(/\{(.*)\}/, "$1").replace(/"_obj":/, "");
                case "object":
                    return JSON.stringify(t);
                case "boolean":
                    return t.toString();
                case "undefined":
                    return "undefined";
                case "null":
                    return "null";
                default:
                    try {
                        return t.toString()
                    } catch (r) {
                        return n = r, ""
                    }
            }
        }, 
        $.parseJson = function(e) {
            var t, n;
            switch ($.type(e)) {
                case "string":
                    try {
                        return $.parseJSON(e)
                    } catch (n) {
                        return t = n, null
                    }
                    break;
                case "object":
                case "array":
                    return e;
                default:
                    return null
            }
        }, 
        $.parseSize = function(e) {
            var t;
            return e ? (t = parseInt(e), t > 1099511627776 ? (t / 1099511627776).toFixed(2) + "TB" : t > 1073741824 ? (t / 1073741824).toFixed(2) + "GB" : t > 1048576 ? (t / 1048576).toFixed(2) + "MB" : t > 1024 ? (t / 1024).toFixed(2) + "KB" : t + "B") : "0B"
        }, 
        $.parseRgb = function(e) {
            var t, n, r, a, i, o, s, c;
            if (~e.search("#")) return e;
            for (c = e.replace(/.*\(|\).*/g, ""), n = c.split(","), s = "#", a = i = 0, o = n.length; o > i; a = ++i) t = n[a], 3 > a && (r = parseInt(t).toString(16), r.length < 2 && (r = "0" + r), s += r);
            return s
        }, 
        $.parseTime = function(e) {
            var t;
            return (t = function(e) {
                var t, n, r, a, i, o, s, c, u, l, d, h;
                return n = new Date(e), l = n.getTime(), r = new Date, h = r.getTime(), d = h - l, i = n.getHours() + "时" + (n.getMinutes() < 10 ? "0" : "") + n.getMinutes() + "分", o = n.getMonth() + 1 + "月" + n.getDate() + "日(星期" + ["日", "一", "二", "三", "四", "五", "六"][n.getDay()] + ") " + i, s = n.getFullYear() + "年" + o, 0 > d ? "刚刚" : d / 31536e6 | 0 ? s : (t = d / 864e5) > 3 ? n.getFullYear() !== r.getFullYear() ? s : o : (t = (r.getDay() - n.getDay() + 7) % 7) > 2 ? o : t > 1 ? "前天 " + i : (a = d / 36e5) > 12 ? (n.getDay() !== r.getDay() ? "昨天 " : "今天 ") + i : (a = d / 36e5 % 60 | 0) ? a + "小时前" : (c = d / 6e4 % 60 | 0) ? c + "分钟前" : (u = d / 1e3 % 60 | 0) > 30 ? u + "秒前" : "刚刚"
            })($.timeStamp(e))
        }, 
        $.parseShortDate = function(e) {
            var t, n, r, a, i, o;
            for (r = "date" === $.type(e) ? e : new Date(e), n = [r.getFullYear(), 1 + r.getMonth(), r.getDate()], a = i = 0, o = n.length; o > i; a = ++i) t = n[a], n[a] = $.parseString(t), a && n[a].length < 2 && (n[a] = "0" + n[a]);
            return n.join("")
        }, 

        $.route = function(e) {
            var n;
            if (!$.route.ready) return n = function() {
                return location.hash ? location.hash.match(/#/g).length > 1 ? void(location.hash = location.hash.replace(/#(.*)#.*/, "#$1")) : ($.hash.data = $.hash.parse(location.hash), "function" == typeof e ? e() : void 0) : void(location.href = "#page=index")
            }, t.on("hashchange", function() {
                return n()
            }), n(), $.route.ready = true
        }, 
        $.hash = function() {
            var e, t, n, a;
            switch (n = 1 <= arguments.length ? r.call(arguments, 0) : [], t = (e = $.hash).data || (e.data = {}), a = function() {
                var e, n, r;
                return e = function() {
                    var e;
                    e = [];
                    for (n in t) r = t[n], null != r && e.push(n + "=" + encodeURIComponent(r));
                    return e
                }().join(";").replace(/(?:&=)||(?:=&)/g, "").replace(/&/g, ";"), location.hash = "#" + (e || ""), t
            }, n.length) {
                case 1:
                    switch ($.type(n[0])) {
                        case "string":
                            return t[n[0]];
                        case "object":
                            return $.extend(t, n[0]), a()
                    }
                    break;
                case 2:
                    return t[n[0]] = n[1], a();
                default:
                    return t
            }
        }, 
        $.hash.parse = function(e) {
            var t, n, r, a, i, o;
            for (o = {}, i = e.replace(/.*#/, "").replace(/[\?&].*/, "").split(";"), r = 0, a = i.length; a > r; r++) t = i[r], t.length && (n = t.split("="), o[n[0]] = decodeURIComponent(n[1]));
            return o
        },

        function() {
            var t, n, r;
            return r = window.sessionStorage, n = $.history = function() {
                return n.data
            }, n._default = function() {
                return ["#page=index", "index"]
            }, n.data = (t = r.getItem("history")) ? $.parseJson(t) : [n._default()], n.push = function() {
                var t, r, i, o, s, c, u, l;
                if (u = e.page || "index", r = location.hash, s = (n.data[n.data.length - 1] || n._default())[1], "index" === u) n.clear();
                else {
                    for (a.call(e.map[u], s) >= 0 || n.data.pop(), l = n.data, i = o = 0, c = l.length; c > o; i = ++o) t = l[i], u === t[1] && (n.data[i] = null);
                    n.data = _.compact(n.data), n.data.push([r, u])
                }
                return $.i("history", s + " -> " + u + " [" + function() {
                    var e, r, a, i;
                    for (a = n.data, i = [], e = 0, r = a.length; r > e; e++) t = a[e], i.push(t[1]);
                    return i
                }().join(", ") + "]"), n.save(), n.data
            }, 
            n.clear = function() {
                return n.data = [n._default()], n.save()
            }, 
            n.back = function() {
                return location.hash = n.last()[0]
            }, 
            n.last = function() {
                return n.data[n.data.length - 2] || n._default()
            }, 
            n.save = function() {
                return r.setItem("history", $.parseString(n.data))
            }
        }(), 

        $.log = function(t) {
            return console.log(t), e.debug && e.log.push(t), t
        },

        function() {
            var e, t;
            return t = $("#layer-info"), e = $.info = function(t) {
                var n, r;
                return r = $.parseString(t), n = $('<div class="item">'), e.render(n, r), e.show(n, function() {
                    return e.check()
                }), $.next(5e3, function() {
                    return e.hide(n, function() {
                        return e.check()
                    })
                })
            }, e.clear = function() {
                return t.empty().addClass("hidden")
            }, e.check = function() {
                var n;
                return n = t.find(".item"), n.length ? n.length > 5 ? e.remove(n.eq(0)) : void 0 : void t.empty().addClass("hidden")
            }, e.hide = function(t, n) {
                var r;
                return r = "fadeOut animated", t.removeClass(r).addClass(r).onAnimationEnd(function() {
                    return e.remove(t), "function" == typeof n ? n() : void 0
                })
            }, e.show = function(e, t) {
                var n;
                return n = "flipInX animated", e.addClass(n).onAnimationEnd(function() {
                    return e.removeClass(n), "function" == typeof t ? t() : void 0
                })
            }, e.render = function(e, n) {
                return e.html(n.replace(/[\r\n]+/g, "<br>").replace(/。</g, "<").replace(/。$/g, "")).appendTo(t.removeClass("hidden")).after("<br>")
            }, e.remove = function(e) {
                return e.next().remove(), e.remove()
            }
        }(), 

        $.i = function() {
            var e, t, n, i, o;
            return n = 1 <= arguments.length ? r.call(arguments, 0) : [], i = 1 === n.length ? ["default", n[0]] : n, o = i[0], t = i[1], a.call($.i.forbidden, o) >= 0 ? t : (e = "default" !== o ? "<" + o.toUpperCase() + "> " + t : t, $.log(e), t)
        }, $.i.forbidden = [], $.i.forbid = function(e) {
            return $.i.forbidden = _.union($.i.forbidden, "array" !== $.type(e) ? [e] : e)
        }, 

        $.fn.swipe = function(t) {
            var n, r;
            return r = $.extend({}, t), n = {}, n.reset = function(e, t) {
                return e.removeClass("_swiping"), t.startX = null, t.startY = null, t.direction = null, t.distance = null, t.scroll = null, t.moved = null
            }, n.check = function(e, t, n) {
                if ("x" === e || "left" === e || "right" === e) {
                    if ("x" !== t) return !1;
                    if ("left" === e && n > 0) return !1;
                    if ("right" === e && 0 > n) return !1
                }
                if ("y" === e || "up" === e || "down" === e) {
                    if ("y" !== t) return !1;
                    if ("up" === e && n > 0) return !1;
                    if ("down" === e && 0 > n) return !1
                }
                return true
            }, n.name = function(e) {
                var t, n, r, a, i;
                for (n = _.trim(e).replace(/\s+/g, " ").split(" "), r = a = 0, i = n.length; i > a; r = ++a) t = n[r], n[r] = t + ".swipe";
                return n.join(" ")
            }, n.bind = function(e, t) {
                return e.on(n.name("touchmove mousemove"), function(a) {
                    var i, o, s, c, u, l, d, h;
                    if (!t.active) return void n.unbind(e, "move");
                    if (~a.type.search("touch") ? i = a.changedTouches[0] : (1 !== a.which && $.i(12), i = a), d = i.pageX, h = i.pageY, o = d - t.startX, s = h - t.startY, !t.direction) {
                        if (Math.pow(o, 2) + Math.pow(s, 2) < 64) return;
                        t.direction = .5 * Math.abs(o) > Math.abs(s) ? "x" : "y"
                    }
                    if (c = "x" === t.direction ? o : s, c !== t.distance) {
                        if (t.distance = c, !n.check(r.direction, t.direction, t.distance)) return void n.unbind(e, "move");
                        if (u = { type: "swipemove", x: d, y: h, direction: t.direction, distance: t.distance, scroll: t.scroll, event: a }, (null != (l = r.check) ? !l.move : true) || r.check.move(u)) return a.preventDefault(), t.moved = true, e.addClass("_swiping"), e.triggerHandler(u)
                    }
                }).on(n.name("touchend touchcancel mouseup mouseleave"), function(a) {
                    var i, o, s, c, u, l, d, h;
                    if (t.active) {
                        if (t.active = !1, ~a.type.search("touch")) i = a.changedTouches[0];
                        else {
                            if (1 !== a.which) return;
                            i = a
                        }
                        if (d = i.pageX, h = i.pageY, o = d - t.startX, s = h - t.startY, c = "x" === t.direction ? o : s, t.moved && (u = { type: "swipeend", x: d, y: h, direction: t.direction, distance: c, scroll: t.scroll, event: a }, (null != (l = r.check) ? !l.end : true) || r.check.end(u))) return e.triggerHandler(u), n.unbind(e), n.reset(e, t)
                    }
                })
            }, n.unbind = function(e, t) {
                switch (t) {
                    case "move":
                        return e.off(n.name("touchmove mousemove"));
                    default:
                        return e.off(n.name("touchmove mousemove touchend touchcancel mouseup mouseleave"))
                }
            }, this.each(function() {
                var t, a;
                return a = $(this), a.data()._swipe ? void $.i("error", "$.fn.swipe(a element has be bound)") : (t = a.data()._swipe = {}, a.on(n.name("touchstart mousedown"), function(i) {
                    var o, s, c, u, l;
                    if (n.unbind(a), n.bind(a, t), n.reset(a, t), ~i.type.search("touch")) o = i.changedTouches[0];
                    else {
                        if (1 !== i.which) return;
                        o = i
                    }
                    return u = t.startX = o.pageX, l = t.startY = o.pageY, t.scroll = { left: e.scroll.left, top: e.scroll.top }, s = { type: "swipestart", x: u, y: l, direction: null, distance: 0, scroll: t.scroll, event: i }, (null != (c = r.check) ? c.start : 0) && !r.check.start(s) ? void 0 : (t.active = true, a.triggerHandler(s))
                }))
            })
        }, 

        $.pageSwipe = function(t) {
            var n, r, i, o, s;
            return i = $.extend({ time: 200 }, t), "wechat" === e.shell && (i.time = 0), r = $.pageSwipe, s = e.page, a.call(r.cache || (r.cache = []), s) >= 0 ? void $.i("swipe", "page already existed in the list") : (r.cache.push(e.page), o = $("#" + e.page), n = o.find(".content"), o.swipe({
                check: {
                    move: function(t) {
                        switch (t.direction) {
                            case "x":
                                return i.right && t.distance > 0 ? true : i.left && t.distance < 0 ? true : !1;
                            case "y":
                                return i.down && 0 === t.scroll.top && t.distance > 0 ? true : i.up && t.scroll.top + e.height > n[0].scrollHeight - 8 && t.distance < 0 ? true : !1
                        }
                    },
                    end: function(t) {
                        switch (t.direction) {
                            case "x":
                                return true;
                            case "y":
                                return 0 === t.scroll.top ? true : t.scroll.top + e.height > n[0].scrollHeight - 8 ? true : !1
                        }
                    }
                }
            }).on("swipemove", function(t) {
                var n;
                if ("wechat" !== e.shell) switch (t.direction) {
                    case "x":
                        return n = t.distance, n > e.width ? n = e.width : n < -e.width && (n = -e.width), o.css($.vendor({ transform: "translate3d(" + n + "px, 0, 0)" })), r.shadow(true, n, i.time)
                }
            }).on("swipeend", function(t) {
                var n;
                switch (t.direction) {
                    case "x":
                        return i.right && t.distance > .25 * e.width ? (o.animate($.vendor({ transform: "translate3d(" + e.width + "px, 0, 0)" }), i.time, function() {
                            return e.vibrate(), "function" == typeof i.right ? i.right() : void 0
                        }), r.shadow(!1, true, i.time)) : i.left && t.distance < .25 * -e.width ? (o.animate($.vendor({ transform: "translate3d(" + e.width + "px, 0, 0)" }), i.time, function() {
                            return e.vibrate(), "function" == typeof i.left ? i.left() : void 0
                        }), r.shadow(!1, true, i.time)) : (o.animate($.vendor({ transform: "translate3d(0, 0, 0)" }), i.time), r.shadow());
                    case "y":
                        if (n = t.distance, Math.abs(n) > 32) return n > 0 ? "function" == typeof i.down ? i.down() : void 0 : "function" == typeof i.up ? i.up() : void 0
                }
            }))
        }, 

        $.pageSwipe.shadow = function(t, n, r) {
            var a, i;
            return null == r && (r = 200), "application" === e.shell && "android" === e.os || "wechat" === e.shell ? void 0 : (i = $("#" + e.page), a = $.history.last()[1], $.require({ html: a, style: a }).done(function() {
                var o, s;
                return o = $("#" + a), t ? (e.busy || (e.busy = true, i.addClass("focus"), o.addClass("swiping"), o.css($.vendor({ transform: "translate3d(" + e.width * -.5 + "px, 0, 0)", filter: "brightness(0.5)" })).removeClass("hidden")), o.css($.vendor({ transform: "translate3d(" + .01 * (-50 + n / e.width * 50) * e.width + "px, 0, 0)", filter: "brightness(" + (.5 + n / e.width * .5) + ")" }))) : (s = $.vendor({ transform: "translate3d(" + (n ? 0 : e.width * -.5 + "px") + ", 0, 0)", filter: "brightness(" + (n ? 1 : .5) + ")" }), o.animate(s, r, function() {
                    return e.busy = !1, i.removeClass("focus"), o.removeClass("swiping"), n ? void 0 : o.addClass("hidden")
                }))
            }))
        }, 

        $.setupSwiper = function(t, n) {
            var r, a, i, o;
            return o = $.extend({ direction: "x" }, n), a = {}, i = t.children().eq(0), r = i.children(), a.time = 200, ("android" === e.os || "wechat" === e.shell) && (a.time = 0), r.addClass("latent"), a.index = 0, a.last = null, a.count = r.length, a.next = function() {
                return a.eq(a.index + 1)
            }, a.prev = function() {
                return a.eq(a.index - 1)
            }, a.eq = function(t, n) {
                var s, c, u, l;
                return a.index = function() {
                    return 0 > t ? 0 : t >= a.count ? a.count - 1 : t
                }(), a.index === a.last ? void("function" == typeof o._callback && o._callback(a.index)) : (l = r.eq(a.index), s = r.filter(":not(.latent)"), l.removeClass("latent"), l.data().ready || ("function" == typeof(c = l.data()).init && c.init(), l.data().ready = true), u = -100 * a.index, i.animate($.vendor({ transform: "translate3d(" + .01 * u * e.width + "px, 0, 0)" }), a.time, "ease", function() {
                    return s.addClass("latent"), a.last = a.index
                }), n ? void 0 : "function" == typeof o.callback ? o.callback(a.index) : void 0)
            }, t.swipe({
                direction: o.direction,
                check: {
                    start: function(e) {
                        return o.exclude && $(e.event.target).closest(o.exclude).length ? !1 : true
                    }
                }
            }).on("swipestart", function() {
                return a.fired = true
            }).on("swipemove", function(t) {
                return a.fired && Math.abs(t.distance) > .25 * e.innerWidth ? (t.distance > 0 ? a.prev() : a.next(), e.vibrate(), a.fired = !1) : void 0
            }).on("swipeend", function() {
                return a.fired ? a.fired = true : void 0
            }), a
        }, 

        $.setupTabb = function(t, n) {
            var r, a, i, o, s;
            return s = $.extend({}, n), i = {}, a = t.children("a"), o = t.children(".indicator"), i.time = 200, "wechat" === e.shell && (i.time = 0), i.width = 96, i.index = 0, i.last = null, i.count = a.length, i.next = function() {
                return i.eq(i.index + 1)
            }, i.prev = function() {
                return i.eq(i.index - 1)
            }, i.eq = function(e, t) {
                return i.index = function() {
                    return 0 > e ? 0 : e >= i.count ? i.count - 1 : e
                }(), i.index !== i.last ? (a.eq(i.index).switchClass("active"), o.animate($.vendor({ transform: "translate3d(" + i.index * i.width + "px, 0, 0)" }), i.time, "ease", function() {
                    return i.last = i.index
                }), t ? void 0 : "function" == typeof s.callback ? s.callback(i.index) : void 0) : void 0
            }, r = "fade in", t.css({ width: i.count * i.width }).addClass(r).removeClass("hidden").onAnimationEnd(function() {
                return t.removeClass(r)
            }).on("click", "a", function() {
                var t;
                return t = $(this), e.sound(), i.eq(t.index())
            }), t.swipe({ direction: "x" }).on("swipestart", function() {
                return i.fired = true
            }).on("swipemove", function(t) {
                return i.fired && Math.abs(t.distance) > .2 * e.innerWidth ? (t.distance > 0 ? i.next() : i.prev(), e.vibrate(), i.fired = !1) : void 0
            }).on("swipeend", function() {
                return i.fired ? i.fired = !1 : void 0
            }), i
        }, 

        $.curtain = function(e, t) {
            var n, r, a, i, o;
            return a = $.Deferred(), o = $.extend({}, t), i = o.element || $("#curtain"), r = i.data(), e ? (r.active = true, n = "fade in", i.addClass(n).removeClass("hidden").onAnimationEnd(function() {
                return i.removeClass(n), a.resolve()
            })) : (r.active = !1, n = "fade out", i.addClass(n).onAnimationEnd(function() {
                return i.addClass("hidden").removeClass(n), a.resolve()
            })), a.promise()
        }, 
        $.curtain.shut = function(e) {
            var t, n, r;
            return r = $.extend({}, e), n = r.element || $("#curtain"), t = n.data(), t.active = !1, n.addClass("hidden").removeClass("fade in out")
        }, 

        $.rnd = function() {
            var e, t;
            switch (e = 1 <= arguments.length ? r.call(arguments, 0) : [], t = Math.random(), e.length) {
                case 1:
                    switch ($.type(e[0])) {
                        case "number":
                            return t * e[0] | 0;
                        case "array":
                            return e[0][t * e[0].length | 0]
                    }
                    break;
                case 2:
                    return e[0] + t * (e[1] - e[0]) | 0;
                default:
                    return 2 * t | 0
            }
        }, 

        $.timeStamp = function(e) {
            var t, n, r, a, i, o, s, c;
            switch ($.type(s = e)) {
                case "number":
                    return s;
                case "string":
                    if (c = $.trim(s), -1 !== c.search(/[\s\.\-\/]/)) {
                        for (-1 !== c.search(/\:/) ? (t = c.split(" "), -1 === t[0].search(/\:/) ? (n = t[0].replace(/[\-\/]/g, ".").split("."), r = t[1].split(":")) : (n = t[1].replace(/[\-\/]/g, ".").split("."), r = t[0].split(":"))) : (n = c.replace(/[\-\/]/g, ".").split("."), r = [0, 0, 0]), i = o = 0; 2 >= o; i = ++o) n[i] = 0 | n[i], r[i] = 0 | (r[i] || 0);
                        return a = new Date, a.setFullYear(n[0], n[1] - 1, n[2]), a.setHours(r[0], r[1], r[2]), 1e3 * (a.getTime() / 1e3 | 0)
                    }
                    return $.now();
                default:
                    return $.now()
            }
        }, 

        $.fn.switchClass = function(e) {
            return this.each(function() {
                return $(this).addClass(e).siblings("." + e).removeClass(e)
            })
        }, 

        $.insertStyle = function(e, t) {
            var n;
            return n = "style-" + e, $("#" + n).remove(), $("<style>").attr({ id: n }).html(t).appendTo("head")
        }, 

        $.preload = function(t) {
            var n, r, a, i, o, s, c;
            switch (a = $.Deferred(), c = "browser" === e.shell, $.type(t)) {
                case "string":
                    s = { list: [t] };
                    break;
                case "array":
                    s = { list: t };
                    break;
                case "object":
                    s = _.clone(t), s.list || (s.list = s.data || s.array), s.each || (s.each = s.every || s.fn || s.callback);
                    break;
                default:
                    s = { list: [] }
            }
            return n = $.unique(s.list), n.length ? (c && (i = $("<img>"), i.on("error", function() {
                return r()
            }).on("load", function() {
                return "function" == typeof s.each && s.each(i.attr("src")), r()
            })), r = function() {
                return n.length ? o() : ($.next(function() {
                    return a.resolve()
                }), c ? i.remove() : void 0)
            }, (o = function() {
                var e;
                return e = $.parseString(n.shift()), c ? i.attr({ src: e }) : $.ajax({
                    type: "GET",
                    url: e,
                    timeout: s.timeout || 0,
                    error: function() {
                        return r()
                    },
                    success: function() {
                        return "function" == typeof s.each && s.each(e), r()
                    }
                })
            })(), a.promise()) : ($.next(function() {
                return a.resolve()
            }), a)
        }, 

        $.vendor = function(e) {
            var t, n, r, i, o, s, c, u, l;
            s = ["webkit", "moz"], o = ["transform", "filter", "animation-duration"], c = u = e;
            for (r in c)
                if (l = c[r], a.call(o, r) >= 0)
                    for (n = 0, i = s.length; i > n; n++) t = s[n], u["-" + t + "-" + r] = l;
            return u
        }, 

        $.fn.onAnimationEnd = function(e) {
            var t;
            return t = window.WebKitTransitionEvent ? "webkitAnimationEnd" : "mozAnimationEnd MSAnimationEnd oanimationend animationend", this.each(function() {
                var n;
                return $(n = this).off(t).one(t, function() {
                    return e.apply(n)
                })
            })
        }, 

        $.next = function() {
            var e, t, n, a;
            return t = 1 <= arguments.length ? r.call(arguments, 0) : [], n = t[1] ? t : [0, t[0]], a = n[0], e = n[1], setTimeout(e, a)
        }, 

        $.filterImage = function(e) {
            var t, n, r, a, i, o, s, c, u, l, d, h, f;
            if (o = $.parseString(e), d = o.match(/\<img[^\>]+/g), !d) return [];
            for (f = [], s = 0, u = d.length; u > s; s++) {
                for (n = d[s], r = $.trim(n.replace(/[\<\\"']/g, "").replace(/\s+/g, " ")).split(" "), h = {}, c = 0, l = r.length; l > c; c++) a = r[c], i = $.trim(a).split("="), i[0] && i[1] && (h[i[0]] = i[1]);
                (t = h["data-src"] || h.src) && f.push(t)
            }
            return _.unique(f), f
        }
}).call(this);
